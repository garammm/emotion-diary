const Emotion = () => {
  return (
    <div>
      <h1>감정분석 페이지</h1>
      <div>당신의 감정은 ______ 입니다.</div>
    </div>
  );
};

export default Emotion;
